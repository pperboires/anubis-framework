package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import net.sourceforge.anubis.domain.ApplicationAccount;

@RooDataOnDemand(entity = ApplicationAccount.class)
public class ApplicationAccountDataOnDemand {
}

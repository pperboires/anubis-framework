package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import net.sourceforge.anubis.domain.RoleTranslation;

@RooDataOnDemand(entity = RoleTranslation.class)
public class RoleTranslationDataOnDemand {
}

package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import net.sourceforge.anubis.domain.Locale;
import org.junit.Test;

@RooIntegrationTest(entity = Locale.class)
public class LocaleIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

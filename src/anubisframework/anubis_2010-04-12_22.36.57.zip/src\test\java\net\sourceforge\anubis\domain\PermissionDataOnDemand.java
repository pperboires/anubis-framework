package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import net.sourceforge.anubis.domain.Permission;

@RooDataOnDemand(entity = Permission.class)
public class PermissionDataOnDemand {
}

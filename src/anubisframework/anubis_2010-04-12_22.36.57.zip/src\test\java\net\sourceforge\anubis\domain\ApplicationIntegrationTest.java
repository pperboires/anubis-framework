package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import net.sourceforge.anubis.domain.Application;
import org.junit.Test;

@RooIntegrationTest(entity = Application.class)
public class ApplicationIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

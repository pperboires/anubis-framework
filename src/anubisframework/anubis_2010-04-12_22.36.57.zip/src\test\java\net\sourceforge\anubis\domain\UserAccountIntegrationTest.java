package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import net.sourceforge.anubis.domain.UserAccount;
import org.junit.Test;

@RooIntegrationTest(entity = UserAccount.class)
public class UserAccountIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

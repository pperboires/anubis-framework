package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import net.sourceforge.anubis.domain.Validity;

@RooDataOnDemand(entity = Validity.class)
public class ValidityDataOnDemand {
}

package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import net.sourceforge.anubis.domain.UserAccount;

@RooDataOnDemand(entity = UserAccount.class)
public class UserAccountDataOnDemand {
}

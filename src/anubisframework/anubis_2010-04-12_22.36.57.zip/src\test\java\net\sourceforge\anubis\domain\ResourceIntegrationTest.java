package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import net.sourceforge.anubis.domain.Resource;
import org.junit.Test;

@RooIntegrationTest(entity = Resource.class)
public class ResourceIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

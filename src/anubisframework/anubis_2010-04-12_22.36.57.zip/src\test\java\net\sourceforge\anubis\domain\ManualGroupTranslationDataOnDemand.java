package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import net.sourceforge.anubis.domain.ManualGroupTranslation;

@RooDataOnDemand(entity = ManualGroupTranslation.class)
public class ManualGroupTranslationDataOnDemand {
}

package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import net.sourceforge.anubis.domain.ResourceTranslation;
import org.junit.Test;

@RooIntegrationTest(entity = ResourceTranslation.class)
public class ResourceTranslationIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import net.sourceforge.anubis.domain.ManualGroupTranslation;
import org.junit.Test;

@RooIntegrationTest(entity = ManualGroupTranslation.class)
public class ManualGroupTranslationIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

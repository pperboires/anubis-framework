package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import net.sourceforge.anubis.domain.ManualGroup;
import org.junit.Test;

@RooIntegrationTest(entity = ManualGroup.class)
public class ManualGroupIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

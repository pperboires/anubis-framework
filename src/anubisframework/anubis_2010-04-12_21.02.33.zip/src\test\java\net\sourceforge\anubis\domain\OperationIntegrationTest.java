package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import net.sourceforge.anubis.domain.Operation;
import org.junit.Test;

@RooIntegrationTest(entity = Operation.class)
public class OperationIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

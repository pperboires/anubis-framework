package net.sourceforge.anubis.domain;

import javax.persistence.Entity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;
import org.springframework.roo.addon.entity.RooEntity;
import javax.persistence.Table;
import javax.persistence.Column;
import java.util.Set;
import net.sourceforge.anubis.domain.GroupTranslation;
import java.util.HashSet;
import javax.validation.constraints.NotNull;
import javax.persistence.OneToMany;
import javax.persistence.CascadeType;

@Entity
@RooJavaBean
@RooToString
@RooEntity(identifierField = "uid", identifierColumn = "uid")
@Table(name = "group")
public abstract class Group {

    @Column(name = "id")
    private String id;

    @Column(name = "enabled")
    private Boolean enabled;

    @NotNull
    @OneToMany(cascade = CascadeType.ALL)
    private Set<GroupTranslation> translations = new HashSet<GroupTranslation>();
}

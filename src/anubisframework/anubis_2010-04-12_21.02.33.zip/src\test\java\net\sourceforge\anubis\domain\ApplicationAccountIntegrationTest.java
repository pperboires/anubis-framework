package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import net.sourceforge.anubis.domain.ApplicationAccount;
import org.junit.Test;

@RooIntegrationTest(entity = ApplicationAccount.class)
public class ApplicationAccountIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

package net.sourceforge.anubis.domain;

import javax.persistence.Entity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;
import org.springframework.roo.addon.entity.RooEntity;
import javax.persistence.Table;
import javax.persistence.Column;
import net.sourceforge.anubis.domain.UserAccount;
import javax.validation.constraints.NotNull;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import net.sourceforge.anubis.domain.Locale;

@Entity
@RooJavaBean
@RooToString
@RooEntity(identifierField = "uid", identifierColumn = "uid")
@Table(name = "user")
public class User {

    @Column(name = "name")
    private String name;

    @NotNull
    @ManyToOne(targetEntity = UserAccount.class)
    @JoinColumn(name = "user_account")
    private UserAccount account;

    @ManyToOne(targetEntity = Locale.class)
    @JoinColumn
    private Locale preferredLocale;
}

package net.sourceforge.anubis.domain;

import net.sourceforge.anubis.domain.Group;
import javax.persistence.Entity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;
import org.springframework.roo.addon.entity.RooEntity;
import javax.persistence.Table;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@RooJavaBean
@RooToString
@RooEntity(identifierField = "uid", identifierColumn = "uid")
@Table(name = "characterized_group")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class CharacterizedGroup extends Group {
}

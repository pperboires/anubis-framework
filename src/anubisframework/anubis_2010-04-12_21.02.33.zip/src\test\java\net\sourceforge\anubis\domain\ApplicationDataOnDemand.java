package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import net.sourceforge.anubis.domain.Application;

@RooDataOnDemand(entity = Application.class)
public class ApplicationDataOnDemand {
}

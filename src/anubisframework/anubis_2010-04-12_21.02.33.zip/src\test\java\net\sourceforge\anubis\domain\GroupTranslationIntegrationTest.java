package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import net.sourceforge.anubis.domain.GroupTranslation;
import org.junit.Test;

@RooIntegrationTest(entity = GroupTranslation.class)
public class GroupTranslationIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

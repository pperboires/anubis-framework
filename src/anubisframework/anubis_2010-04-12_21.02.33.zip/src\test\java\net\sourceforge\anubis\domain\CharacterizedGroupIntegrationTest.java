package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import net.sourceforge.anubis.domain.CharacterizedGroup;
import org.junit.Test;

@RooIntegrationTest(entity = CharacterizedGroup.class)
public class CharacterizedGroupIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import net.sourceforge.anubis.domain.OperationTranslation;
import org.junit.Test;

@RooIntegrationTest(entity = OperationTranslation.class)
public class OperationTranslationIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

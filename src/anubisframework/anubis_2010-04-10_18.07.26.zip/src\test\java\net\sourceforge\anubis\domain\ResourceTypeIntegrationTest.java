package net.sourceforge.anubis.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import net.sourceforge.anubis.domain.ResourceType;
import org.junit.Test;

@RooIntegrationTest(entity = ResourceType.class)
public class ResourceTypeIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
